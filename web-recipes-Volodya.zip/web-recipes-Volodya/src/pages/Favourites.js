import React from 'react';

function Favourites() {
  return (
    <div className="favourites page">
      <div className="header">
        <h1>Избранное</h1>
      </div>
    </div>
  );
}

export default Favourites;
