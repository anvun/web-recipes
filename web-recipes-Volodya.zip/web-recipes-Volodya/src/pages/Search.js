import React from 'react';

function Search(props) {
    return (
        <div>
            <h1>Поиск</h1>
            <input type="search"></input> 
        </div>
    );
}

export default Search;