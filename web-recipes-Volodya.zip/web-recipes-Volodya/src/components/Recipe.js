import React, { Component } from 'react';



export default Recipe;
